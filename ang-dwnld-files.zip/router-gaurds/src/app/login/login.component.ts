import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
t1:string;t2:string;
  constructor() { }
  funlogin(){
    if(this.t1=="scott" && this.t2=="scott123")
    {
      localStorage.setItem("aut","abcd")
    }
    else
    {
      alert("Invalid")
    }
  }
  ngOnInit() {
  }

}
