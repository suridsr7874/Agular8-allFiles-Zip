import { Component, OnInit } from '@angular/core';
import { RoutergaurdService } from '../routergaurd.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private rotobj:RoutergaurdService,private rt:Router) { }
t1:string;t2:string;
  ngOnInit() {
  }
  funlogin(){
    if(this.t1=="scott" && this.t2=="scott123")
    {
    localStorage.setItem("aut","1")
    this.rotobj.tmp=true
      this.rt.navigateByUrl("welc")
    }
  }

}
