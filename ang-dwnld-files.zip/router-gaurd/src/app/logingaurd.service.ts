import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class LogingaurdService implements CanActivate {
canActivate(){
  if(localStorage.getItem("aut"))
  return false;
  else
  return true;
}
  constructor() { }
}
