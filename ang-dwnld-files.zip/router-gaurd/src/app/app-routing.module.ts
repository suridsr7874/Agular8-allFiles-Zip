import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ServicesComponent } from './services/services.component';
import { LoginComponent } from './login/login.component';
import { RoutergaurdService } from './routergaurd.service';
import { LogoutComponent } from './logout/logout.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { LogingaurdService } from './logingaurd.service';

const routes: Routes = [
  {path:"hm",component:HomeComponent},
  {path:"ab",component:AboutComponent},
  {path:"ser",component:ServicesComponent,canActivate:[RoutergaurdService]},
  {path:"login",component:LoginComponent,canActivate:[LogingaurdService]},
  {path:"logout",component:LogoutComponent},
  {path:"welc",component:WelcomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
