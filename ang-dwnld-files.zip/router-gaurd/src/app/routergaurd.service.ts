import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class RoutergaurdService implements CanActivate{
  tmp;
 
canActivate(){
  if(localStorage.getItem("aut"))
  return true;
  else
  return false;
}
  constructor() { 
    if(localStorage.getItem("aut"))
    this.tmp= true;
    else
    this.tmp=false;
  }
}
