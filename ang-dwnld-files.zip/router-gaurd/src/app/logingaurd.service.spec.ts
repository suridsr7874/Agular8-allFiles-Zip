import { TestBed } from '@angular/core/testing';

import { LogingaurdService } from './logingaurd.service';

describe('LogingaurdService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LogingaurdService = TestBed.get(LogingaurdService);
    expect(service).toBeTruthy();
  });
});
