import { Component, OnInit } from '@angular/core';
import { RoutergaurdService } from '../routergaurd.service';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {

  constructor(private obj:RoutergaurdService) { 
    this.obj.tmp=false
    localStorage.clear()
  }

  ngOnInit() {
  }

}
