import { AboutComponent } from "./about/about.component";
import { ContactComponent } from './contact/contact.component';
import {Routes} from "@angular/router"
export var obj:Routes=[
{path:"ab",component:AboutComponent},
{path:"cn",component:ContactComponent}]