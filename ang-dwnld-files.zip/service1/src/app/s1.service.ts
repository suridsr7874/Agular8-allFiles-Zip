import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class S1Service {
sno:number=100
  constructor() { }
}
