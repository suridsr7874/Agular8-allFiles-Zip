import { Cls1 } from './cls1';

describe('Cls1', () => {
  it('should create an instance', () => {
    expect(new Cls1()).toBeTruthy();
  });
});
