export class Cls1 {
    sno:number=100
}
